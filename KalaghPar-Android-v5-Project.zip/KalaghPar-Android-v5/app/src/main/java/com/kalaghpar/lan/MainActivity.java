package com.kalaghpar.lan;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.ValueCallback;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.graphics.Color;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private LanBridge lanBridge;
    private ValueCallback<Uri[]> filePickerCallback;
    private String pendingSaveName;
    private String pendingSaveText;
    private static final int FILE_PICKER_REQUEST = 7101;
    private static final int SAVE_FILE_REQUEST = 7102;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.rgb(21, 27, 34));
        getWindow().setNavigationBarColor(Color.rgb(21, 27, 34));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(15, 19, 24));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        lanBridge = new LanBridge(this, new PageMessenger() {
            @Override public void post(String json) {
                runOnUiThread(() -> {
                    if (webView != null) {
                        String quoted = org.json.JSONObject.quote(json);
                        webView.evaluateJavascript("if(window.KalaghParLanMessage){window.KalaghParLanMessage(" + quoted + ");}", null);
                    }
                });
            }
        });
        webView.addJavascriptInterface(lanBridge, "KalaghParNativeLan");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePickerCallback != null) filePickerCallback.onReceiveValue(null);
                filePickerCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, FILE_PICKER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePickerCallback = null;
                    return false;
                }
            }
        });
        webView.setWebViewClient(new WebViewClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICKER_REQUEST) {
            if (filePickerCallback != null) {
                Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                filePickerCallback.onReceiveValue(result);
                filePickerCallback = null;
            }
        } else if (requestCode == SAVE_FILE_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingSaveText != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new IllegalStateException("فایل قابل ذخیره‌سازی نیست.");
                    out.write(pendingSaveText.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "فایل پشتیبان ذخیره شد.", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "ذخیره فایل ناموفق بود.", Toast.LENGTH_LONG).show();
                }
            }
            pendingSaveName = null;
            pendingSaveText = null;
        }
    }

    @Override
    protected void onDestroy() {
        if (lanBridge != null) lanBridge.shutdown();
        if (webView != null) {
            webView.removeJavascriptInterface("KalaghParNativeLan");
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    private void saveTextFileFromJs(String fileName, String content) {
        runOnUiThread(() -> {
            try {
                pendingSaveName = (fileName == null || fileName.trim().isEmpty()) ? "kalagh-par-backup.json" : fileName.replaceAll("[^a-zA-Z0-9._-]", "_");
                pendingSaveText = content == null ? "" : content;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, pendingSaveName);
                startActivityForResult(intent, SAVE_FILE_REQUEST);
            } catch (Exception e) {
                Toast.makeText(this, "باز کردن پنجره ذخیره فایل ممکن نشد.", Toast.LENGTH_LONG).show();
            }
        });
    }

    public interface PageMessenger { void post(String json); }

    public static final class LanBridge {
        private final LanServer server;
        private final MainActivity activity;

        LanBridge(MainActivity activity, PageMessenger messenger) {
            this.activity = activity;
            server = new LanServer(activity.getApplicationContext(), messenger::post);
        }

        @JavascriptInterface
        public String startHost(String json) {
            try {
                return new org.json.JSONObject()
                    .put("ok", true)
                    .put("room", server.startHost(new org.json.JSONObject(json)))
                    .toString();
            } catch (Exception e) {
                return error(e.getMessage());
            }
        }

        @JavascriptInterface
        public String scanRooms() {
            try {
                return new org.json.JSONObject().put("ok", true).put("rooms", server.scanRooms()).toString();
            } catch (Exception e) { return error(e.getMessage()); }
        }

        @JavascriptInterface
        public String send(String json) {
            try {
                server.hostSend(new org.json.JSONObject(json));
                return "{\"ok\":true}";
            } catch (Exception e) { return error(e.getMessage()); }
        }

        @JavascriptInterface
        public String stopHost() {
            try { server.stopHost(); return "{\"ok\":true}"; }
            catch (Exception e) { return error(e.getMessage()); }
        }

        @JavascriptInterface
        public String leaveRoom() {
            return "{\"ok\":true}";
        }

        @JavascriptInterface
        public String saveTextFile(String fileName, String content) {
            try {
                activity.saveTextFileFromJs(fileName, content);
                return "{\"ok\":true}";
            } catch (Exception e) { return error(e.getMessage()); }
        }

        void shutdown() { server.shutdown(); }

        private String error(String message) {
            try { return new org.json.JSONObject().put("ok", false).put("error", message == null ? "native_error" : message).toString(); }
            catch (Exception ignored) { return "{\"ok\":false,\"error\":\"native_error\"}"; }
        }
    }
}
