package com.kalaghpar.lan;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;

/** Native WebSocket host + Android NSD service discovery for Kalagh-Par. */
final class LanServer {
    interface MessageSink { void post(String json); }

    private static final String SERVICE_TYPE = "_kalaghpar._tcp.";
    private static final int MAX_FRAME_BYTES = 1024 * 1024;
    private final Context context;
    private final MessageSink sink;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final NsdManager nsd;
    private final CopyOnWriteArrayList<Peer> peers = new CopyOnWriteArrayList<>();
    private final Map<String, JSONObject> discovered = new LinkedHashMap<>();
    private final Object roomLock = new Object();

    private volatile boolean running = false;
    private volatile boolean started = false;
    private ServerSocket serverSocket;
    private Thread acceptThread;
    private JSONObject room;
    private String hostId;
    private String advertisedServiceName;
    private NsdManager.RegistrationListener registrationListener;
    private NsdManager.DiscoveryListener discoveryListener;
    private Handler discoveryHandler;
    private Runnable discoveryTimeout;
    private WifiManager.MulticastLock multicastLock;

    LanServer(Context context, MessageSink sink) {
        this.context = context.getApplicationContext();
        this.sink = sink;
        this.nsd = (NsdManager) this.context.getSystemService(Context.NSD_SERVICE);
    }

    JSONObject startHost(JSONObject request) throws Exception {
        stopHost();
        final int port = clamp(request.optInt("port", 8765), 1024, 65535, 8765);
        final String roomName = safeText(request.optString("roomName", "گروه کلاغ‌پر"), 24, "گروه کلاغ‌پر");
        final String name = safeText(request.optString("hostName", "میزبان"), 24, "میزبان");
        final String id = safeText(request.optString("hostId", "host-" + UUID.randomUUID().toString().substring(0, 8)), 48, "host");
        final int maxPlayers = clamp(request.optInt("maxPlayers", 4), 2, 6, 4);
        final boolean hostParticipates = request.optBoolean("hostParticipates", true);
        final String localIp = findLocalIpv4();

        ServerSocket socket = new ServerSocket();
        socket.setReuseAddress(true);
        socket.bind(new java.net.InetSocketAddress("0.0.0.0", port), 16);
        serverSocket = socket;
        hostId = id;
        running = true;
        started = false;

        JSONObject created = new JSONObject();
        created.put("roomId", "kp-" + UUID.randomUUID().toString().replace("-", "").substring(0, 10));
        created.put("name", roomName);
        created.put("hostId", id);
        created.put("hostName", name);
        created.put("ip", localIp);
        created.put("port", port);
        created.put("maxPlayers", maxPlayers);
        created.put("config", request.optJSONObject("config") == null ? new JSONObject() : new JSONObject(request.optJSONObject("config").toString()));
        JSONArray players = new JSONArray();
        if (hostParticipates) {
            JSONObject host = new JSONObject();
            host.put("id", id); host.put("name", name); host.put("isHost", true);
            host.put("ready", false); host.put("connected", true); host.put("slot", 0);
            players.put(host);
        }
        created.put("players", players);
        synchronized (roomLock) { room = created; }

        acceptThread = new Thread(this::acceptLoop, "KalaghPar-LAN-Accept");
        acceptThread.start();
        registerNsd(roomName, created.optString("roomId"), port, maxPlayers);
        return roomSnapshot();
    }

    JSONArray scanRooms() {
        synchronized (discovered) { discovered.clear(); }
        beginDiscovery();
        synchronized (discovered) {
            JSONArray result = new JSONArray();
            for (JSONObject item : discovered.values()) result.put(cloneJson(item));
            return result;
        }
    }

    void hostSend(JSONObject message) throws Exception {
        if (!running) throw new IOException("سرور گروه فعال نیست.");
        String sender = message.optString("senderId", "");
        if (!hostId.equals(sender)) throw new SecurityException("شناسه میزبان معتبر نیست.");
        handleMessage(null, message, true);
    }

    void stopHost() {
        if (!running && room == null) return;
        try { broadcast(new JSONObject().put("type", "host_left")); } catch (Exception ignored) {}
        running = false;
        started = false;
        unregisterNsd();
        stopDiscovery();
        ServerSocket old = serverSocket;
        serverSocket = null;
        if (old != null) try { old.close(); } catch (IOException ignored) {}
        for (Peer peer : peers) peer.closeQuietly();
        peers.clear();
        synchronized (roomLock) { room = null; }
        hostId = null;
    }

    void shutdown() { stopHost(); stopDiscovery(); }

    private void acceptLoop() {
        while (running) {
            try {
                Socket socket = serverSocket.accept();
                socket.setTcpNoDelay(true);
                socket.setKeepAlive(true);
                Peer peer = new Peer(socket);
                peers.add(peer);
                peer.start();
            } catch (IOException e) {
                if (running) postError("پذیرش اتصال شبکه با خطا مواجه شد.");
                break;
            }
        }
    }

    private void handleMessage(Peer peer, JSONObject message, boolean fromHost) {
        String type = message.optString("type", "");
        if (peer != null && !peer.joined) {
            if (!"join".equals(type)) { peer.send(errorMessage("ابتدا باید درخواست ورود ارسال شود.")); peer.closeQuietly(); return; }
            handleJoin(peer, message);
            return;
        }

        String sender = message.optString("senderId", "");
        if (!fromHost && (peer == null || !peer.playerId.equals(sender))) {
            if (peer != null) peer.send(errorMessage("شناسه بازیکن معتبر نیست."));
            return;
        }
        if (fromHost && !hostId.equals(sender)) return;

        try {
            if ("ready".equals(type)) {
                if (started) return;
                synchronized (roomLock) {
                    JSONObject player = findPlayer(sender);
                    if (player == null || player.optBoolean("connected", true) == false) return;
                    player.put("ready", message.optBoolean("ready", false));
                }
                broadcastRoom();
            } else if ("config_update".equals(type)) {
                if (!fromHost || started) { sendToPeer(peer, errorMessage("فقط میزبان می‌تواند پیش از شروع تنظیمات را تغییر دهد.")); return; }
                JSONObject config = message.optJSONObject("config");
                if (config == null) return;
                int newMax = clamp(message.optInt("maxPlayers", config.optInt("players", 4)), 2, 6, 4);
                synchronized (roomLock) {
                    JSONArray roster = room.optJSONArray("players");
                    if (roster != null && roster.length() > newMax) {
                        postError("ظرفیت جدید از تعداد بازیکنان حاضر کمتر است.");
                        return;
                    }
                    room.put("name", safeText(message.optString("roomName", room.optString("name")), 24, room.optString("name")));
                    room.put("maxPlayers", newMax);
                    room.put("config", new JSONObject(config.toString()));
                }
                broadcastRoom();
                refreshNsdAdvertisement();
            } else if ("kick".equals(type)) {
                if (!fromHost || started) return;
                String target = message.optString("playerId", "");
                if (target.isEmpty() || target.equals(hostId)) return;
                Peer found = null;
                for (Peer p : peers) if (target.equals(p.playerId)) { found = p; break; }
                if (found != null) {
                    found.send(typeMessage("kicked"));
                    found.closeQuietly();
                    peers.remove(found);
                }
                synchronized (roomLock) { removePlayer(target); }
                broadcastRoom();
            } else if ("start_request".equals(type)) {
                if (!fromHost || started) return;
                JSONObject cfg;
                int connected = 0;
                boolean allReady = true;
                synchronized (roomLock) {
                    JSONArray roster = room.optJSONArray("players");
                    if (roster != null) for (int i = 0; i < roster.length(); i++) {
                        JSONObject p = roster.optJSONObject(i);
                        if (p == null || !p.optBoolean("connected", true)) continue;
                        connected++;
                        if (!p.optBoolean("ready", false)) allReady = false;
                    }
                    cfg = room.optJSONObject("config");
                }
                if (connected < 2) { postError("برای شروع حداقل دو بازیکن لازم است."); return; }
                if (!allReady) { postError("هنوز همه بازیکنان آماده نشده‌اند."); return; }
                started = true;
                JSONObject start = new JSONObject().put("type", "game_start")
                    .put("config", cfg == null ? new JSONObject() : new JSONObject(cfg.toString()))
                    .put("startAt", System.currentTimeMillis() + 3000L);
                broadcast(start);
            }
        } catch (Exception e) {
            sendToPeer(peer, errorMessage(e.getMessage() == null ? "خطای داخلی گروه" : e.getMessage()));
        }
    }

    private void handleJoin(Peer peer, JSONObject message) {
        try {
            if (!running || room == null) { peer.send(errorMessage("گروه دیگر فعال نیست.")); peer.closeQuietly(); return; }
            if (message.optInt("protocol", 0) != 1) { peer.send(errorMessage("نسخه پروتکل سازگار نیست.")); peer.closeQuietly(); return; }
            String roomId = message.optString("roomId", "");
            if (!roomId.isEmpty() && !roomId.equals(room.optString("roomId"))) { peer.send(errorMessage("شناسه گروه اشتباه است.")); peer.closeQuietly(); return; }
            String id = safeText(message.optString("playerId", ""), 48, "");
            if (id.isEmpty() || id.equals(hostId)) { peer.send(errorMessage("شناسه بازیکن معتبر نیست.")); peer.closeQuietly(); return; }
            String name = safeText(message.optString("playerName", "بازیکن"), 24, "بازیکن");
            synchronized (roomLock) {
                JSONArray roster = room.optJSONArray("players");
                JSONObject existing = findPlayer(id);
                if (existing == null && (roster == null || roster.length() >= room.optInt("maxPlayers", 6))) {
                    peer.send(errorMessage("ظرفیت گروه تکمیل شده است.")); peer.closeQuietly(); return;
                }
                int slot = existing == null ? nextSlot(roster) : existing.optInt("slot", 1);
                if (existing == null) {
                    existing = new JSONObject();
                    existing.put("id", id); existing.put("slot", slot);
                    roster.put(existing);
                }
                existing.put("name", name); existing.put("isHost", false);
                existing.put("ready", false); existing.put("connected", true);
                peer.playerId = id; peer.joined = true;
            }
            peer.send(new JSONObject().put("type", "connected").put("room", roomSnapshot()));
            broadcastRoom();
        } catch (Exception e) {
            peer.send(errorMessage("ورود به گروه انجام نشد."));
            peer.closeQuietly();
        }
    }

    private int nextSlot(JSONArray roster) {
        boolean[] used = new boolean[6];
        if (roster != null) for (int i = 0; i < roster.length(); i++) {
            JSONObject p = roster.optJSONObject(i);
            if (p != null) { int s = p.optInt("slot", -1); if (s >= 0 && s < used.length) used[s] = true; }
        }
        for (int i = 0; i < used.length; i++) if (!used[i]) return i;
        return used.length - 1;
    }

    private JSONObject findPlayer(String id) {
        if (room == null) return null;
        JSONArray roster = room.optJSONArray("players");
        if (roster == null) return null;
        for (int i = 0; i < roster.length(); i++) {
            JSONObject p = roster.optJSONObject(i);
            if (p != null && id.equals(p.optString("id"))) return p;
        }
        return null;
    }

    private void removePlayer(String id) {
        if (room == null) return;
        JSONArray old = room.optJSONArray("players");
        JSONArray next = new JSONArray();
        if (old != null) for (int i = 0; i < old.length(); i++) {
            JSONObject p = old.optJSONObject(i);
            if (p != null && !id.equals(p.optString("id"))) next.put(p);
        }
        try { room.put("players", next); } catch (Exception ignored) {}
    }

    private void peerDisconnected(Peer peer) {
        peers.remove(peer);
        if (!running || !peer.joined || peer.playerId == null) return;
        synchronized (roomLock) {
            JSONObject player = findPlayer(peer.playerId);
            if (player != null) {
                try { player.put("connected", false); player.put("ready", false); }
                catch (Exception ignored) {}
            }
        }
        broadcastRoom();
    }

    private void broadcastRoom() {
        try { broadcast(new JSONObject().put("type", "room_update").put("room", roomSnapshot())); }
        catch (Exception ignored) {}
    }

    private void broadcast(JSONObject message) {
        String text = message.toString();
        for (Peer peer : peers) if (peer.joined) peer.sendText(text);
        postToPage(text);
    }

    private void sendToPeer(Peer peer, JSONObject message) {
        if (peer != null) peer.send(message);
        else postToPage(message.toString());
    }

    private void postError(String message) {
        try { postToPage(new JSONObject().put("type", "error").put("message", message).toString()); }
        catch (Exception ignored) {}
    }

    private void postToPage(String json) { if (sink != null) sink.post(json); }

    private JSONObject roomSnapshot() {
        synchronized (roomLock) { return room == null ? new JSONObject() : cloneJson(room); }
    }

    private static JSONObject typeMessage(String type) {
        try { return new JSONObject().put("type", type); }
        catch (Exception e) { return new JSONObject(); }
    }

    private static JSONObject errorMessage(String text) {
        try { return new JSONObject().put("type", "error").put("message", text == null ? "خطای شبکه" : text); }
        catch (Exception e) { return new JSONObject(); }
    }

    private static JSONObject cloneJson(JSONObject source) {
        try { return source == null ? new JSONObject() : new JSONObject(source.toString()); }
        catch (Exception e) { return new JSONObject(); }
    }

    private void registerNsd(String roomName, String roomId, int port, int maxPlayers) {
        if (nsd == null) return;
        try {
            NsdServiceInfo service = new NsdServiceInfo();
            service.setServiceName("KalaghPar-" + roomId);
            service.setServiceType(SERVICE_TYPE);
            service.setPort(port);
            service.setAttribute("roomid", roomId);
            service.setAttribute("roomname", roomName);
            service.setAttribute("max", String.valueOf(maxPlayers));
            registrationListener = new NsdManager.RegistrationListener() {
                @Override public void onServiceRegistered(NsdServiceInfo info) { advertisedServiceName = info.getServiceName(); }
                @Override public void onRegistrationFailed(NsdServiceInfo info, int errorCode) { registrationListener = null; }
                @Override public void onServiceUnregistered(NsdServiceInfo info) { }
                @Override public void onUnregistrationFailed(NsdServiceInfo info, int errorCode) { }
            };
            nsd.registerService(service, NsdManager.PROTOCOL_DNS_SD, registrationListener);
        } catch (Exception ignored) {
            // Manual IP entry remains available if hotspot firmware blocks mDNS advertisement.
        }
    }

    private void refreshNsdAdvertisement() {
        JSONObject snapshot = roomSnapshot();
        unregisterNsd();
        main.postDelayed(() -> {
            if (!running || room == null) return;
            registerNsd(snapshot.optString("name", "گروه کلاغ‌پر"), snapshot.optString("roomId", ""),
                snapshot.optInt("port", 8765), snapshot.optInt("maxPlayers", 6));
        }, 300L);
    }

    private void unregisterNsd() {
        if (nsd != null && registrationListener != null) {
            try { nsd.unregisterService(registrationListener); } catch (Exception ignored) {}
        }
        registrationListener = null;
        advertisedServiceName = null;
    }

    private void beginDiscovery() {
        if (nsd == null) { emitRooms(); return; }
        stopDiscovery();
        acquireMulticastLock();
        discoveryListener = new NsdManager.DiscoveryListener() {
            @Override public void onDiscoveryStarted(String serviceType) { }
            @Override public void onServiceFound(NsdServiceInfo info) {
                if (info == null || !SERVICE_TYPE.equals(info.getServiceType())) return;
                try {
                    nsd.resolveService(info, new NsdManager.ResolveListener() {
                        @Override public void onResolveFailed(NsdServiceInfo service, int errorCode) { }
                        @Override public void onServiceResolved(NsdServiceInfo service) {
                            try {
                                InetAddress host = service.getHost();
                                if (host == null) return;
                                Map<String, byte[]> attrs = service.getAttributes();
                                String roomId = attr(attrs, "roomid", "");
                                String name = attr(attrs, "roomname", service.getServiceName());
                                int max = parseInt(attr(attrs, "max", "6"), 6);
                                JSONObject item = new JSONObject();
                                item.put("roomId", roomId); item.put("name", name);
                                item.put("ip", host.getHostAddress()); item.put("port", service.getPort());
                                item.put("maxPlayers", max); item.put("players", 0);
                                synchronized (discovered) { discovered.put(service.getServiceName(), item); }
                                emitRooms();
                            } catch (Exception ignored) { }
                        }
                    });
                } catch (Exception ignored) { }
            }
            @Override public void onServiceLost(NsdServiceInfo info) {
                if (info != null) {
                    synchronized (discovered) { discovered.remove(info.getServiceName()); }
                    emitRooms();
                }
            }
            @Override public void onDiscoveryStopped(String serviceType) { }
            @Override public void onStartDiscoveryFailed(String serviceType, int errorCode) { stopDiscovery(); emitRooms(); }
            @Override public void onStopDiscoveryFailed(String serviceType, int errorCode) { }
        };
        try {
            nsd.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, discoveryListener);
            discoveryHandler = main;
            discoveryTimeout = this::stopDiscovery;
            main.postDelayed(discoveryTimeout, 6500L);
        } catch (Exception e) {
            stopDiscovery(); emitRooms();
        }
    }

    private void emitRooms() {
        try {
            JSONArray array = new JSONArray();
            synchronized (discovered) { for (JSONObject item : discovered.values()) array.put(cloneJson(item)); }
            postToPage(new JSONObject().put("type", "rooms").put("rooms", array).toString());
        } catch (Exception ignored) { }
    }

    private void stopDiscovery() {
        if (discoveryTimeout != null && discoveryHandler != null) discoveryHandler.removeCallbacks(discoveryTimeout);
        discoveryTimeout = null; discoveryHandler = null;
        if (nsd != null && discoveryListener != null) {
            try { nsd.stopServiceDiscovery(discoveryListener); } catch (Exception ignored) {}
        }
        discoveryListener = null;
        releaseMulticastLock();
    }

    @SuppressWarnings("deprecation")
    private void acquireMulticastLock() {
        try {
            WifiManager wifi = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wifi != null && (multicastLock == null || !multicastLock.isHeld())) {
                multicastLock = wifi.createMulticastLock("KalaghPar-mDNS");
                multicastLock.setReferenceCounted(false);
                multicastLock.acquire();
            }
        } catch (Exception ignored) { }
    }

    private void releaseMulticastLock() {
        try { if (multicastLock != null && multicastLock.isHeld()) multicastLock.release(); }
        catch (Exception ignored) { }
        multicastLock = null;
    }

    private static String attr(Map<String, byte[]> attrs, String key, String fallback) {
        if (attrs == null || !attrs.containsKey(key)) return fallback;
        try { return new String(attrs.get(key), StandardCharsets.UTF_8); }
        catch (Exception e) { return fallback; }
    }

    private static int parseInt(String value, int fallback) {
        try { return Integer.parseInt(value); } catch (Exception e) { return fallback; }
    }

    private static String safeText(String value, int max, String fallback) {
        if (value == null) return fallback;
        String result = value.replaceAll("[\\r\\n\\u0000-\\u001F]", " ").trim();
        if (result.isEmpty()) return fallback;
        return result.length() > max ? result.substring(0, max) : result;
    }

    private static int clamp(int value, int min, int max, int fallback) {
        if (value < min || value > max) return fallback;
        return value;
    }

    private static String findLocalIpv4() {
        try {
            List<String> candidates = new ArrayList<>();
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces != null && interfaces.hasMoreElements()) {
                NetworkInterface ni = interfaces.nextElement();
                if (!ni.isUp() || ni.isLoopback() || ni.isVirtual()) continue;
                Enumeration<InetAddress> addresses = ni.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    InetAddress address = addresses.nextElement();
                    if (!(address instanceof Inet4Address) || address.isLoopbackAddress() || address.isLinkLocalAddress()) continue;
                    String ip = address.getHostAddress();
                    if (address.isSiteLocalAddress()) {
                        String iface = ni.getName().toLowerCase();
                        int score = (iface.contains("wlan") || iface.contains("ap") || iface.contains("wifi") || iface.contains("swlan")) ? 0 : 1;
                        candidates.add(score + "|" + ip);
                    }
                }
            }
            Collections.sort(candidates);
            if (!candidates.isEmpty()) return candidates.get(0).substring(2);
        } catch (Exception ignored) { }
        return "";
    }

    private final class Peer {
        private final Socket socket;
        private final Object writeLock = new Object();
        private volatile boolean closed = false;
        private volatile boolean joined = false;
        private volatile String playerId;
        private BufferedInputStream input;
        private OutputStream output;

        Peer(Socket socket) { this.socket = socket; }

        void start() { new Thread(this::run, "KalaghPar-LAN-Peer").start(); }

        void run() {
            try {
                input = new BufferedInputStream(socket.getInputStream());
                output = socket.getOutputStream();
                String headers = readHttpHeaders(input);
                String key = headerValue(headers, "sec-websocket-key");
                if (key == null || !headers.startsWith("GET ")) throw new IOException("Invalid WebSocket handshake");
                String accept = websocketAccept(key.trim());
                String response = "HTTP/1.1 101 Switching Protocols\r\n" +
                    "Upgrade: websocket\r\nConnection: Upgrade\r\n" +
                    "Sec-WebSocket-Accept: " + accept + "\r\n\r\n";
                synchronized (writeLock) { output.write(response.getBytes(StandardCharsets.US_ASCII)); output.flush(); }
                readFrames();
            } catch (Exception ignored) {
            } finally {
                closeQuietly();
                peerDisconnected(this);
            }
        }

        private void readFrames() throws IOException {
            while (!closed && running && !socket.isClosed()) {
                int first = input.read();
                if (first < 0) break;
                int second = input.read();
                if (second < 0) break;
                int opcode = first & 0x0F;
                boolean masked = (second & 0x80) != 0;
                long length = second & 0x7F;
                if (length == 126) length = readUnsignedShort(input);
                else if (length == 127) length = readLong(input);
                if (length < 0 || length > MAX_FRAME_BYTES) throw new IOException("WebSocket frame too large");
                byte[] mask = masked ? readExact(input, 4) : null;
                byte[] payload = readExact(input, (int) length);
                if (masked) for (int i = 0; i < payload.length; i++) payload[i] = (byte) (payload[i] ^ mask[i % 4]);
                if (opcode == 0x8) break;
                if (opcode == 0x9) { sendFrame(0xA, payload); continue; }
                if (opcode == 0x1) {
                    String text = new String(payload, StandardCharsets.UTF_8);
                    try { handleMessage(this, new JSONObject(text), false); }
                    catch (Exception ignored) { send(errorMessage("پیام ارسالی قابل خواندن نیست.")); }
                }
            }
        }

        void send(JSONObject json) { sendText(json.toString()); }

        void sendText(String text) { sendFrame(0x1, text.getBytes(StandardCharsets.UTF_8)); }

        private void sendFrame(int opcode, byte[] payload) {
            if (closed || output == null) return;
            try {
                synchronized (writeLock) {
                    output.write(0x80 | (opcode & 0x0F));
                    int len = payload.length;
                    if (len <= 125) output.write(len);
                    else if (len <= 65535) { output.write(126); output.write((len >>> 8) & 0xFF); output.write(len & 0xFF); }
                    else {
                        output.write(127);
                        long n = len;
                        for (int i = 7; i >= 0; i--) output.write((int) ((n >>> (8 * i)) & 0xFF));
                    }
                    output.write(payload);
                    output.flush();
                }
            } catch (IOException e) { closeQuietly(); }
        }

        void closeQuietly() {
            if (closed) return;
            closed = true;
            try { socket.close(); } catch (IOException ignored) { }
        }
    }

    private static String readHttpHeaders(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int state = 0;
        while (out.size() < 16384) {
            int b = in.read();
            if (b < 0) throw new IOException("Handshake ended");
            out.write(b);
            if ((state == 0 || state == 2) && b == '\r') state++;
            else if ((state == 1 || state == 3) && b == '\n') state++;
            else state = (b == '\r') ? 1 : 0;
            if (state == 4) return out.toString("US-ASCII");
        }
        throw new IOException("Handshake too large");
    }

    private static String headerValue(String headers, String name) {
        String[] lines = headers.split("\\r\\n");
        for (String line : lines) {
            int colon = line.indexOf(':');
            if (colon > 0 && line.substring(0, colon).trim().equalsIgnoreCase(name)) return line.substring(colon + 1).trim();
        }
        return null;
    }

    private static String websocketAccept(String key) throws Exception {
        String source = key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
        byte[] hash = MessageDigest.getInstance("SHA-1").digest(source.getBytes(StandardCharsets.US_ASCII));
        return android.util.Base64.encodeToString(hash, android.util.Base64.NO_WRAP);
    }

    private static int readUnsignedShort(InputStream in) throws IOException {
        int a = in.read(), b = in.read();
        if (a < 0 || b < 0) throw new IOException("Unexpected end of frame");
        return (a << 8) | b;
    }

    private static long readLong(InputStream in) throws IOException {
        long n = 0;
        for (int i = 0; i < 8; i++) { int b = in.read(); if (b < 0) throw new IOException("Unexpected end of frame"); n = (n << 8) | (b & 0xff); }
        return n;
    }

    private static byte[] readExact(InputStream in, int length) throws IOException {
        byte[] data = new byte[length];
        int offset = 0;
        while (offset < length) {
            int n = in.read(data, offset, length - offset);
            if (n < 0) throw new IOException("Unexpected end of frame");
            offset += n;
        }
        return data;
    }
}
